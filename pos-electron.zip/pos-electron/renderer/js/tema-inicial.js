// Aplica el tema guardado ANTES de pintar la pagina, para que no haya parpadeo
// (un flash de tema claro justo antes de pasar a oscuro).
// Va en un archivo aparte (en vez de un <script> inline) porque la politica
// de seguridad de la app (CSP: script-src 'self') no permite scripts inline.
(function () {
  try {
    var tema = localStorage.getItem('fly-sell-theme');
    if (tema === 'dark' || (!tema && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark');
    }
  } catch (e) {}
})();
