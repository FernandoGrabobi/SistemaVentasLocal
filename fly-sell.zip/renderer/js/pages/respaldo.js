import { showToast, formatearFecha } from '../toast.js';

export async function renderRespaldo(root) {
  root.innerHTML = `
    <div class="p-6 flex flex-col gap-4 h-full overflow-y-auto">
      <h1 class="text-xl font-semibold">Copias de seguridad</h1>

      <div id="aviso-copia" class="hidden rounded-lg px-4 py-3 text-sm"></div>

      <div class="card">
        <h2 class="font-semibold mb-1">Guardar una copia ahora</h2>
        <p class="text-sm text-gray-500 dark:text-gray-400 mb-3">
          Genera un archivo con todos tus datos (productos, stock, ventas, clientes, caja y fotos).
          Elegí dónde guardarlo: lo ideal es un pendrive o una carpeta de la nube (Drive, Dropbox).
        </p>
        <button id="btn-guardar" class="btn-primary">Guardar copia en...</button>
      </div>

      <div class="card">
        <h2 class="font-semibold mb-1">Copia automática</h2>
        <p class="text-sm text-gray-500 dark:text-gray-400 mb-3">
          Se guarda sola al cerrar la caja y al abrir el sistema (si pasó más de un día). Se conservan solo las últimas copias.
        </p>
        <label class="flex items-center gap-2 text-sm mb-3">
          <input id="chk-auto" type="checkbox" />
          <span>Activar copia automática</span>
        </label>
        <div class="grid grid-cols-1 gap-3 max-w-xl">
          <div>
            <label class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Carpeta de las copias</label>
            <div class="flex items-center gap-2 mt-1">
              <div id="carpeta-auto" class="input flex-1 truncate text-sm"></div>
              <button id="btn-carpeta" class="btn-secondary whitespace-nowrap">Cambiar</button>
              <button id="btn-abrir-carpeta" class="btn-secondary whitespace-nowrap">Abrir</button>
            </div>
            <p id="nota-carpeta" class="hidden text-xs text-amber-600 dark:text-amber-400 mt-1">
              Esta carpeta está en la misma PC. Si se rompe el disco, se pierden también las copias: cambiala por un pendrive o una carpeta de la nube.
            </p>
          </div>
          <div class="flex items-center gap-3">
            <div>
              <label class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Copias a conservar</label>
              <input id="max-copias" type="number" min="1" max="365" class="input mt-1 w-28" />
            </div>
            <div class="self-end text-sm text-gray-500 dark:text-gray-400" id="cant-copias"></div>
          </div>
          <div>
            <button id="btn-copiar-ahora" class="btn-secondary">Hacer copia automática ahora</button>
          </div>
        </div>
      </div>

      <div class="card">
        <h2 class="font-semibold mb-1">Restaurar una copia</h2>
        <p class="text-sm text-gray-500 dark:text-gray-400 mb-3">
          Reemplaza todos los datos actuales por los de una copia guardada. Antes de reemplazar se guarda automáticamente una copia de los datos actuales por si te equivocás. La aplicación se reinicia al terminar.
        </p>
        <button id="btn-restaurar" class="btn-danger">Restaurar desde un archivo...</button>
      </div>
    </div>
  `;

  const avisoEl = document.getElementById('aviso-copia');
  const chkAuto = document.getElementById('chk-auto');
  const carpetaEl = document.getElementById('carpeta-auto');
  const notaCarpeta = document.getElementById('nota-carpeta');
  const maxCopiasEl = document.getElementById('max-copias');
  const cantCopiasEl = document.getElementById('cant-copias');

  function pintarEstado(e) {
    chkAuto.checked = e.autoActivada;
    carpetaEl.textContent = e.carpetaAuto;
    carpetaEl.title = e.carpetaAuto;
    notaCarpeta.classList.toggle('hidden', !e.carpetaEsPorDefecto);
    maxCopiasEl.value = e.maxCopias;
    cantCopiasEl.textContent = `Copias automáticas guardadas: ${e.cantidadCopiasAuto}`;

    avisoEl.classList.remove('hidden');
    avisoEl.className = 'rounded-lg px-4 py-3 text-sm';
    if (!e.ultimaCopiaISO) {
      avisoEl.textContent = 'Todavía no se hizo ninguna copia de seguridad. Guardá una ahora.';
      avisoEl.classList.add('bg-red-50', 'text-red-700', 'dark:bg-red-900/30', 'dark:text-red-300');
    } else if (e.diasDesdeUltima >= 7) {
      avisoEl.textContent = `La última copia es de hace ${e.diasDesdeUltima} días (${formatearFecha(e.ultimaCopiaISO.slice(0, 19).replace('T', ' '))}). Conviene hacer una nueva.`;
      avisoEl.classList.add('bg-amber-50', 'text-amber-700', 'dark:bg-amber-900/30', 'dark:text-amber-300');
    } else {
      const fecha = new Date(e.ultimaCopiaISO).toLocaleString('es-AR', { hour12: false });
      avisoEl.textContent = `Última copia: ${fecha}`;
      avisoEl.classList.add('bg-green-50', 'text-green-700', 'dark:bg-green-900/30', 'dark:text-green-300');
    }
  }

  async function cargar() {
    const res = await window.api.backup.estado();
    if (res.ok) pintarEstado(res.data);
  }

  document.getElementById('btn-guardar').addEventListener('click', async () => {
    const res = await window.api.backup.guardarManual();
    if (!res.ok) return showToast('No se pudo guardar la copia: ' + res.error, 'error');
    if (res.data) {
      showToast('Copia guardada', 'success');
      cargar();
    }
  });

  chkAuto.addEventListener('change', async () => {
    const res = await window.api.backup.configurar({ autoActivada: chkAuto.checked });
    if (!res.ok) return showToast(res.error, 'error');
    showToast(chkAuto.checked ? 'Copia automática activada' : 'Copia automática desactivada', 'success');
    pintarEstado(res.data);
  });

  maxCopiasEl.addEventListener('change', async () => {
    const res = await window.api.backup.configurar({ maxCopias: maxCopiasEl.value });
    if (!res.ok) {
      showToast(res.error, 'error');
      return cargar();
    }
    pintarEstado(res.data);
  });

  document.getElementById('btn-carpeta').addEventListener('click', async () => {
    const res = await window.api.backup.elegirCarpetaAuto();
    if (!res.ok) return showToast(res.error, 'error');
    if (res.data) {
      showToast('Carpeta actualizada', 'success');
      pintarEstado(res.data);
    }
  });

  document.getElementById('btn-abrir-carpeta').addEventListener('click', async () => {
    const res = await window.api.backup.abrirCarpetaAuto();
    if (!res.ok) showToast('No se pudo abrir la carpeta: ' + res.error, 'error');
  });

  document.getElementById('btn-copiar-ahora').addEventListener('click', async () => {
    const res = await window.api.backup.copiarAhora();
    if (!res.ok) return showToast('No se pudo hacer la copia: ' + res.error, 'error');
    if (!res.data) return showToast('La copia automática está desactivada', 'info');
    showToast('Copia automática guardada', 'success');
    cargar();
  });

  document.getElementById('btn-restaurar').addEventListener('click', async () => {
    const res = await window.api.backup.restaurar();
    if (!res.ok) return showToast('No se pudo restaurar: ' + res.error, 'error');
    if (res.data) showToast('Copia restaurada. Reiniciando el sistema...', 'success');
  });

  await cargar();
}
