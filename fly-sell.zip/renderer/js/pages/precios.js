import { showToast, formatearMoneda } from '../toast.js';
import { pedirDatos } from '../dialogo.js';

let listaSeleccionadaId = null;
let listaSeleccionadaNombre = '';

export async function renderPrecios(root) {
  root.innerHTML = `
    <div class="p-6 grid grid-cols-[280px_1fr] gap-6 h-full overflow-hidden">
      <div class="card flex flex-col gap-3 overflow-hidden">
        <div class="flex items-center justify-between">
          <h2 class="font-semibold">Listas de precios</h2>
        </div>
        <div class="flex gap-2">
          <input id="nueva-lista" class="input" placeholder="Nueva lista (ej: Mayorista)" />
          <button id="btn-crear-lista" class="btn-primary px-3">+</button>
        </div>
        <div id="listas-container" class="flex-1 overflow-y-auto flex flex-col gap-1"></div>
      </div>

      <div class="card flex flex-col overflow-hidden" id="panel-lista">
        <div class="text-gray-400 dark:text-gray-500 text-center py-12">Elegí o creá una lista de precios para ver sus productos.</div>
      </div>
    </div>
  `;

  document.getElementById('btn-crear-lista').addEventListener('click', async () => {
    const input = document.getElementById('nueva-lista');
    if (!input.value.trim()) return;
    const res = await window.api.listasPrecio.crear(input.value);
    if (!res.ok) {
      showToast('No se pudo crear la lista: ' + res.error, 'error');
      return;
    }
    input.value = '';
    showToast('Lista creada', 'success');
    listaSeleccionadaId = res.data.id;
    await cargarListas();
    await cargarPanelLista();
  });

  await cargarListas();
  if (listaSeleccionadaId) await cargarPanelLista();
}

async function cargarListas() {
  const res = await window.api.listasPrecio.listar();
  const listas = res.ok ? res.data : [];
  const cont = document.getElementById('listas-container');
  const sel = listas.find((l) => l.id === listaSeleccionadaId);
  listaSeleccionadaNombre = sel ? sel.nombre : '';

  if (listas.length === 0) {
    cont.innerHTML = `<div class="text-sm text-gray-400 dark:text-gray-500 py-4 text-center">Sin listas todavía.</div>`;
    return;
  }

  cont.innerHTML = listas
    .map(
      (l) => `<div class="flex items-center justify-between rounded-lg px-3 py-2 cursor-pointer ${
        listaSeleccionadaId === l.id ? 'bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-400' : 'hover:bg-gray-50 dark:hover:bg-gray-700'
      }" data-lista="${l.id}">
      <span class="text-sm font-medium">${l.nombre}</span>
      <button class="text-red-400 hover:text-red-600 dark:hover:text-red-400 text-xs" data-borrar-lista="${l.id}">✕</button>
    </div>`
    )
    .join('');

  cont.querySelectorAll('[data-lista]').forEach((el) =>
    el.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      listaSeleccionadaId = Number(el.dataset.lista);
      cargarListas();
      cargarPanelLista();
    })
  );
  cont.querySelectorAll('[data-borrar-lista]').forEach((btn) =>
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm('¿Borrar esta lista de precios? Los clientes que la tenían asignada quedan sin lista.')) return;
      await window.api.listasPrecio.eliminar(Number(btn.dataset.borrarLista));
      if (listaSeleccionadaId === Number(btn.dataset.borrarLista)) listaSeleccionadaId = null;
      showToast('Lista eliminada', 'success');
      cargarListas();
      cargarPanelLista();
    })
  );
}

async function cargarPanelLista() {
  const panel = document.getElementById('panel-lista');
  if (!listaSeleccionadaId) {
    panel.innerHTML = `<div class="text-gray-400 dark:text-gray-500 text-center py-12">Elegí o creá una lista de precios para ver sus productos.</div>`;
    return;
  }

  // Traemos el nombre aca mismo (cargarListas corre en paralelo y podria no haber terminado)
  const resListas = await window.api.listasPrecio.listar();
  const sel = resListas.ok ? resListas.data.find((l) => l.id === listaSeleccionadaId) : null;
  listaSeleccionadaNombre = sel ? sel.nombre : '';

  panel.innerHTML = `
    <div class="mb-3">
      <h2 class="font-semibold">Lista: ${listaSeleccionadaNombre}</h2>
      <p class="text-sm text-gray-500 dark:text-gray-400">
        Acá definís productos que, para los clientes de esta lista, se venden a otro precio (por ejemplo, más barato para mayoristas).
        Los productos que no cargues acá se siguen vendiendo a su precio normal.
      </p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
        Para que funcione: asigná esta lista a un cliente (pantalla <b>Clientes</b>) y, al vender, elegí a ese cliente en la pantalla <b>Venta</b> <i>antes</i> de escanear los productos.
      </p>
    </div>
    <div class="flex items-center gap-2 mb-3">
      <input id="buscar-producto" class="input flex-1" placeholder="Buscar producto por nombre o código para agregarle un precio especial..." />
    </div>
    <div id="resultados-busqueda" class="mb-3"></div>
    <div class="flex-1 overflow-y-auto">
      <table class="table-base">
        <thead><tr><th>Producto</th><th class="text-right">Precio base</th><th class="text-right">Precio especial</th><th></th></tr></thead>
        <tbody id="precios-body"></tbody>
      </table>
    </div>
  `;

  document.getElementById('buscar-producto').addEventListener('input', debounce(buscarProductos, 250));
  await cargarPrecios();
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

async function buscarProductos(e) {
  const busqueda = e.target.value.trim();
  const cont = document.getElementById('resultados-busqueda');
  if (!busqueda) {
    cont.innerHTML = '';
    return;
  }
  const res = await window.api.productos.listar({ busqueda });
  const productos = res.ok ? res.data.slice(0, 6) : [];

  if (productos.length === 0) {
    cont.innerHTML = `<div class="text-sm text-gray-400 dark:text-gray-500">Sin resultados.</div>`;
    return;
  }

  cont.innerHTML = `<div class="border border-gray-200 dark:border-gray-700 rounded-lg divide-y">
    ${productos
      .map(
        (p) => `<div class="flex items-center justify-between px-3 py-2 text-sm">
        <span>${p.nombre} <span class="text-gray-400 dark:text-gray-500">· ${formatearMoneda(p.precio)}</span></span>
        <button class="text-brand-600 dark:text-brand-400 hover:underline text-xs" data-agregar="${p.id}" data-precio-base="${p.precio}">+ Agregar precio especial</button>
      </div>`
      )
      .join('')}
  </div>`;

  cont.querySelectorAll('[data-agregar]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const producto = productos.find((p) => p.id === Number(btn.dataset.agregar));
      const datos = await pedirDatos({
        titulo: 'Precio especial',
        descripcion: `${producto ? producto.nombre : 'Producto'} — precio normal: ${formatearMoneda(btn.dataset.precioBase)}. Escribí el precio para la lista "${listaSeleccionadaNombre}".`,
        campos: [{ name: 'precio', label: 'Precio especial', value: btn.dataset.precioBase, type: 'number', min: 0, step: '0.01', required: true }],
      });
      if (!datos) return;
      const r = await window.api.listasPrecio.fijarPrecio(listaSeleccionadaId, Number(btn.dataset.agregar), Number(datos.precio));
      if (!r.ok) {
        showToast('No se pudo guardar: ' + r.error, 'error');
        return;
      }
      showToast('Precio especial guardado', 'success');
      document.getElementById('buscar-producto').value = '';
      cont.innerHTML = '';
      cargarPrecios();
    })
  );
}

async function cargarPrecios() {
  const res = await window.api.listasPrecio.listarPrecios(listaSeleccionadaId);
  const precios = res.ok ? res.data : [];
  const body = document.getElementById('precios-body');

  if (precios.length === 0) {
    body.innerHTML = `<tr><td colspan="4" class="text-center text-gray-400 dark:text-gray-500 py-8">Sin precios especiales cargados. Buscá un producto arriba para agregar uno.</td></tr>`;
    return;
  }

  body.innerHTML = precios
    .map(
      (p) => `<tr>
      <td class="font-medium">${p.producto_nombre}</td>
      <td class="text-right text-gray-400 dark:text-gray-500">${formatearMoneda(p.precio_base)}</td>
      <td class="text-right font-semibold">${formatearMoneda(p.precio)}</td>
      <td class="text-right">
        <button class="text-brand-600 dark:text-brand-400 hover:underline text-sm" data-editar-precio="${p.id}" data-producto="${p.producto_id}" data-actual="${p.precio}">Editar</button>
        <button class="text-red-500 dark:text-red-400 hover:underline text-sm ml-2" data-quitar="${p.id}">Quitar</button>
      </td>
    </tr>`
    )
    .join('');

  body.querySelectorAll('[data-editar-precio]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const datos = await pedirDatos({
        titulo: 'Editar precio especial',
        descripcion: `Lista "${listaSeleccionadaNombre}"`,
        campos: [{ name: 'precio', label: 'Precio especial', value: btn.dataset.actual, type: 'number', min: 0, step: '0.01', required: true }],
      });
      if (!datos) return;
      const r = await window.api.listasPrecio.fijarPrecio(listaSeleccionadaId, Number(btn.dataset.producto), Number(datos.precio));
      if (!r.ok) {
        showToast('No se pudo guardar: ' + r.error, 'error');
        return;
      }
      showToast('Precio actualizado', 'success');
      cargarPrecios();
    })
  );
  body.querySelectorAll('[data-quitar]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await window.api.listasPrecio.quitarPrecio(Number(btn.dataset.quitar));
      showToast('Precio especial quitado', 'success');
      cargarPrecios();
    })
  );
}
