// Cuadro de dialogo propio para pedir datos al usuario.
// Reemplaza a window.prompt(), que Electron no soporta (devuelve null/no hace nada).
//
// Uso:
//   const datos = await pedirDatos({
//     titulo: 'Editar proveedor',
//     descripcion: 'texto opcional',
//     campos: [{ name: 'nombre', label: 'Nombre', value: 'Arcor', required: true },
//              { name: 'margen', label: 'Margen (%)', type: 'number', min: 0, step: '0.01' }],
//   });
//   if (!datos) return; // cancelado
//   datos.nombre, datos.margen  -> strings
export function pedirDatos({ titulo, descripcion = '', campos, textoOk = 'Guardar' }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/40';

    const card = document.createElement('div');
    card.className = 'card w-full max-w-sm';

    const h = document.createElement('h2');
    h.className = 'text-lg font-semibold mb-2';
    h.textContent = titulo;
    card.appendChild(h);

    if (descripcion) {
      const d = document.createElement('p');
      d.className = 'text-sm text-gray-500 dark:text-gray-400 mb-3';
      d.textContent = descripcion;
      card.appendChild(d);
    }

    const inputs = {};
    campos.forEach((c) => {
      const wrap = document.createElement('div');
      wrap.className = 'mb-3';
      const label = document.createElement('label');
      label.className = 'text-sm font-medium text-gray-700 dark:text-gray-300';
      label.textContent = c.label;
      const input = document.createElement('input');
      input.className = 'input mt-1';
      input.type = c.type || 'text';
      if (c.min != null) input.min = c.min;
      if (c.step != null) input.step = c.step;
      if (c.placeholder) input.placeholder = c.placeholder;
      input.value = c.value != null ? String(c.value) : '';
      inputs[c.name] = input;
      wrap.appendChild(label);
      wrap.appendChild(input);
      card.appendChild(wrap);
    });

    const error = document.createElement('div');
    error.className = 'hidden text-sm text-red-600 dark:text-red-400 mb-2';
    card.appendChild(error);

    const botones = document.createElement('div');
    botones.className = 'flex justify-end gap-2 mt-2';
    const btnCancelar = document.createElement('button');
    btnCancelar.type = 'button';
    btnCancelar.className = 'btn-secondary';
    btnCancelar.textContent = 'Cancelar';
    const btnOk = document.createElement('button');
    btnOk.type = 'button';
    btnOk.className = 'btn-primary';
    btnOk.textContent = textoOk;
    botones.appendChild(btnCancelar);
    botones.appendChild(btnOk);
    card.appendChild(botones);

    overlay.appendChild(card);
    document.body.appendChild(overlay);

    function cerrar(resultado) {
      document.removeEventListener('keydown', onKey, true);
      overlay.remove();
      resolve(resultado);
    }

    function confirmar() {
      const datos = {};
      for (const c of campos) {
        const valor = inputs[c.name].value.trim();
        if (c.required && !valor) {
          error.textContent = `Completá el campo "${c.label}".`;
          error.classList.remove('hidden');
          inputs[c.name].focus();
          return;
        }
        if (c.type === 'number' && valor !== '') {
          const n = Number(valor);
          if (isNaN(n) || (c.min != null && n < Number(c.min))) {
            error.textContent = `El valor de "${c.label}" no es válido.`;
            error.classList.remove('hidden');
            inputs[c.name].focus();
            return;
          }
        }
        datos[c.name] = valor;
      }
      cerrar(datos);
    }

    function onKey(e) {
      if (e.key === 'Escape') {
        e.stopPropagation();
        cerrar(null);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        confirmar();
      }
    }
    document.addEventListener('keydown', onKey, true);

    btnCancelar.addEventListener('click', () => cerrar(null));
    btnOk.addEventListener('click', confirmar);

    const primero = inputs[campos[0].name];
    primero.focus();
    primero.select();
  });
}
