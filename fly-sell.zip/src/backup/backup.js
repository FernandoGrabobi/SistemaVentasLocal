// Copias de seguridad de la base de datos (pos.db).
// - Guardar: genera una copia consistente con la API de backup de SQLite
//   (segura aunque la app este en medio de una venta, a diferencia de
//   copiar el archivo a mano).
// - Restaurar: valida el archivo elegido, guarda antes una copia de seguridad
//   de los datos actuales y reemplaza la base; despues reinicia la app.
// - Automatica: copia en una carpeta configurada y se queda con las ultimas N.
const { app, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const db = require('../db');

const userData = app.getPath('userData');
const dbPath = path.join(userData, 'pos.db');
const configPath = path.join(userData, 'backup-config.json');
const carpetaSeguridad = path.join(userData, 'copias-previas-a-restaurar');

const PREFIJO_AUTO = 'FlySell-auto-';
const TABLAS_REQUERIDAS = ['productos', 'ventas', 'venta_detalle', 'lotes', 'turnos_caja', 'clientes'];
const HORAS_ENTRE_AUTO_AL_INICIAR = 20;

function carpetaAutoPorDefecto() {
  return path.join(app.getPath('documents'), 'FlySell-copias');
}

function leerConfig() {
  const base = {
    autoActivada: true,
    carpetaAuto: carpetaAutoPorDefecto(),
    maxCopias: 15,
    ultimaCopiaISO: null, // ultima copia hecha (manual o automatica)
    ultimaAutoISO: null,
  };
  try {
    return { ...base, ...JSON.parse(fs.readFileSync(configPath, 'utf-8')) };
  } catch (e) {
    return base;
  }
}

function guardarConfig(cfg) {
  fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2), 'utf-8');
}

function sello(fecha = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${fecha.getFullYear()}-${p(fecha.getMonth() + 1)}-${p(fecha.getDate())}-${p(fecha.getHours())}${p(fecha.getMinutes())}`;
}

function listarCopiasAuto(carpeta) {
  try {
    return fs
      .readdirSync(carpeta)
      .filter((n) => n.startsWith(PREFIJO_AUTO) && n.endsWith('.db'))
      .map((n) => ({ nombre: n, ruta: path.join(carpeta, n), mtime: fs.statSync(path.join(carpeta, n)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);
  } catch (e) {
    return [];
  }
}

function podarCopiasAuto(carpeta, maxCopias) {
  const copias = listarCopiasAuto(carpeta);
  for (const c of copias.slice(Math.max(1, maxCopias))) {
    try {
      fs.unlinkSync(c.ruta);
    } catch (e) {}
  }
}

async function copiarA(destino) {
  fs.mkdirSync(path.dirname(destino), { recursive: true });
  await db.backup(destino);
}

// --- Estado para mostrar en pantalla ---
function estado() {
  const cfg = leerConfig();
  const copias = listarCopiasAuto(cfg.carpetaAuto);
  let diasDesdeUltima = null;
  if (cfg.ultimaCopiaISO) {
    diasDesdeUltima = Math.floor((Date.now() - new Date(cfg.ultimaCopiaISO).getTime()) / 86400000);
  }
  return {
    autoActivada: cfg.autoActivada,
    carpetaAuto: cfg.carpetaAuto,
    maxCopias: cfg.maxCopias,
    ultimaCopiaISO: cfg.ultimaCopiaISO,
    diasDesdeUltima,
    cantidadCopiasAuto: copias.length,
    carpetaEsPorDefecto: cfg.carpetaAuto === carpetaAutoPorDefecto(),
  };
}

function registrarCopia(auto) {
  const cfg = leerConfig();
  const ahora = new Date().toISOString();
  cfg.ultimaCopiaISO = ahora;
  if (auto) cfg.ultimaAutoISO = ahora;
  guardarConfig(cfg);
}

// --- Guardar (manual) ---
async function guardarManual() {
  const res = await dialog.showSaveDialog({
    title: 'Guardar copia de seguridad',
    defaultPath: path.join(app.getPath('documents'), `FlySell-copia-${sello()}.db`),
    filters: [{ name: 'Copia de Fly Sell', extensions: ['db'] }],
  });
  if (res.canceled || !res.filePath) return null;
  if (path.resolve(res.filePath) === path.resolve(dbPath)) {
    throw new Error('No se puede guardar la copia encima de la base de datos en uso');
  }
  await copiarA(res.filePath);
  registrarCopia(false);
  return { ruta: res.filePath };
}

// --- Automatica ---
async function copiaAutomatica() {
  const cfg = leerConfig();
  if (!cfg.autoActivada) return null;
  const destino = path.join(cfg.carpetaAuto, `${PREFIJO_AUTO}${sello()}.db`);
  await copiarA(destino);
  podarCopiasAuto(cfg.carpetaAuto, cfg.maxCopias);
  registrarCopia(true);
  return { ruta: destino };
}

// Se usa al iniciar la app: si pasaron mas de ~20hs desde la ultima copia
// automatica, hace una. Nunca lanza error (no debe molestar al arrancar).
async function copiaAutomaticaSiCorresponde() {
  try {
    const cfg = leerConfig();
    if (!cfg.autoActivada) return;
    const ult = cfg.ultimaAutoISO ? new Date(cfg.ultimaAutoISO).getTime() : 0;
    if (Date.now() - ult >= HORAS_ENTRE_AUTO_AL_INICIAR * 3600000) {
      await copiaAutomatica();
    }
  } catch (e) {
    console.error('Copia automatica al iniciar fallo:', e.message);
  }
}

function configurar({ autoActivada, maxCopias }) {
  const cfg = leerConfig();
  if (typeof autoActivada === 'boolean') cfg.autoActivada = autoActivada;
  if (maxCopias != null) {
    const n = Math.round(Number(maxCopias));
    if (!Number.isFinite(n) || n < 1 || n > 365) throw new Error('La cantidad de copias debe estar entre 1 y 365');
    cfg.maxCopias = n;
  }
  guardarConfig(cfg);
  return estado();
}

async function elegirCarpetaAuto() {
  const res = await dialog.showOpenDialog({
    title: 'Elegir carpeta para las copias automáticas (idealmente un pendrive o una carpeta de la nube)',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (res.canceled || res.filePaths.length === 0) return null;
  const cfg = leerConfig();
  cfg.carpetaAuto = res.filePaths[0];
  guardarConfig(cfg);
  return estado();
}

async function abrirCarpetaAuto() {
  const cfg = leerConfig();
  fs.mkdirSync(cfg.carpetaAuto, { recursive: true });
  const err = await shell.openPath(cfg.carpetaAuto);
  if (err) throw new Error(err);
  return true;
}

// --- Restaurar ---
function validarArchivoCopia(ruta) {
  let lector;
  try {
    lector = new Database(ruta, { readonly: true, fileMustExist: true });
  } catch (e) {
    throw new Error('El archivo elegido no es una base de datos válida');
  }
  try {
    const existentes = lector
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
      .all()
      .map((r) => r.name);
    const faltan = TABLAS_REQUERIDAS.filter((t) => !existentes.includes(t));
    if (faltan.length > 0) {
      throw new Error('El archivo no parece ser una copia de Fly Sell (faltan tablas)');
    }
    const integridad = lector.pragma('integrity_check', { simple: true });
    if (integridad !== 'ok') {
      throw new Error('El archivo de copia está dañado y no se puede restaurar');
    }
  } catch (e) {
    if (/^El archivo/.test(e.message)) throw e;
    throw new Error('El archivo elegido no es una base de datos válida');
  } finally {
    lector.close();
  }
}

async function restaurar() {
  const res = await dialog.showOpenDialog({
    title: 'Elegir la copia de seguridad a restaurar',
    filters: [{ name: 'Copia de Fly Sell', extensions: ['db'] }],
    properties: ['openFile'],
  });
  if (res.canceled || res.filePaths.length === 0) return null;
  const origen = res.filePaths[0];

  if (path.resolve(origen) === path.resolve(dbPath)) {
    throw new Error('Elegiste la base de datos que ya está en uso');
  }
  validarArchivoCopia(origen);

  const conf = await dialog.showMessageBox({
    type: 'warning',
    title: 'Restaurar copia de seguridad',
    message: 'Esto reemplaza TODOS los datos actuales por los de la copia elegida.',
    detail:
      'Se van a perder las ventas, el stock y los cambios hechos después de que se creó esa copia.\n\n' +
      'Antes de reemplazar, se guarda una copia de los datos actuales por si te equivocás.\n\n' +
      'Archivo: ' + origen,
    buttons: ['Cancelar', 'Restaurar y reiniciar'],
    defaultId: 0,
    cancelId: 0,
  });
  if (conf.response !== 1) return null;

  // 1) copia de seguridad de lo actual (red de seguridad)
  const previa = path.join(carpetaSeguridad, `antes-de-restaurar-${sello()}.db`);
  await copiarA(previa);

  // 2) reemplazar la base: cerrar la conexion y pisar el archivo (+ limpiar WAL/SHM)
  db.close();
  try {
    for (const sufijo of ['-wal', '-shm']) {
      try {
        fs.unlinkSync(dbPath + sufijo);
      } catch (e) {}
    }
    fs.copyFileSync(origen, dbPath);
  } catch (e) {
    // La conexion ya esta cerrada: reiniciamos para volver a abrir la base
    // (los datos originales siguen en la copia previa por si hiciera falta).
    setTimeout(() => {
      app.relaunch();
      app.exit(0);
    }, 800);
    throw new Error('No se pudo restaurar (' + e.message + '). La app se va a reiniciar; tus datos anteriores están guardados en: ' + previa);
  }

  // 3) reiniciar la app con los datos restaurados (damos un instante para responder a la UI)
  setTimeout(() => {
    app.relaunch();
    app.exit(0);
  }, 800);

  return { reiniciando: true, copiaPrevia: previa };
}

module.exports = {
  estado,
  guardarManual,
  copiaAutomatica,
  copiaAutomaticaSiCorresponde,
  configurar,
  elegirCarpetaAuto,
  abrirCarpetaAuto,
  restaurar,
};
