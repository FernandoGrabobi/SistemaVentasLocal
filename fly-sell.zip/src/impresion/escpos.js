// Genera el ticket como comandos ESC/POS (bytes crudos) en vez de HTML,
// para enviarlo directo a la impresora termica sin pasar por el dialogo
// de impresion de Windows/Chromium (que en impresoras como la POS-58
// puede salir en blanco por problemas de pagina/overflow).
const fs = require('fs');
const path = require('path');
const iconv = require('iconv-lite');

// Imagen del logo (eagle de High Software) ya convertida a bitmap monocromo
// y empaquetada como comando ESC/POS "GS v 0" (raster bit image), lista
// para mandar tal cual. Se genera una sola vez offline a partir del logo
// original (assets/logo-source.png); si el archivo no esta, simplemente
// no se imprime el logo (no rompe el ticket).
const LOGO_PATH = path.join(__dirname, '..', '..', 'assets', 'logo-escpos.bin');
let logoBufferCache;
function obtenerLogoBuffer() {
  if (logoBufferCache === undefined) {
    try {
      logoBufferCache = fs.readFileSync(LOGO_PATH);
    } catch (e) {
      logoBufferCache = null;
    }
  }
  return logoBufferCache;
}

const ANCHO = 32; // columnas aproximadas en una termica de 58mm, fuente normal

function formatearMoneda(valor) {
  return '$' + Number(valor || 0).toFixed(2);
}

function pad(izq, der, ancho = ANCHO) {
  izq = String(izq);
  der = String(der);
  const espacio = ancho - izq.length - der.length;
  if (espacio <= 0) return (izq + der).slice(0, ancho);
  return izq + ' '.repeat(espacio) + der;
}

function centrar(texto, ancho = ANCHO) {
  texto = String(texto);
  if (texto.length >= ancho) return texto.slice(0, ancho);
  const totalEspacio = ancho - texto.length;
  const izq = Math.floor(totalEspacio / 2);
  return ' '.repeat(izq) + texto;
}

// Arma el ticket como texto plano, una linea por renglon, pensado para
// 32 columnas (ancho tipico de una termica de 58mm en fuente normal).
function textoTicket(venta) {
  const lineas = [];
  const fecha = new Date().toLocaleString('es-AR', { hour12: false });
  lineas.push(centrar('TICKET DE VENTA'));
  lineas.push(centrar(fecha));
  lineas.push('-'.repeat(ANCHO));

  for (const item of venta.items) {
    const nombre = `${item.cantidad} x ${item.nombre}`;
    const importe = formatearMoneda(item.cantidad * item.precio);
    if (nombre.length + importe.length + 1 > ANCHO) {
      lineas.push(nombre.slice(0, ANCHO));
      lineas.push(pad('', importe));
    } else {
      lineas.push(pad(nombre, importe));
    }
  }

  lineas.push('-'.repeat(ANCHO));
  lineas.push(pad('TOTAL', formatearMoneda(venta.total)));
  lineas.push(pad('Pago', venta.metodo_pago));
  if (venta.metodo_pago === 'efectivo') {
    lineas.push(pad('Recibido', formatearMoneda(venta.monto_recibido)));
    lineas.push(pad('Vuelto', formatearMoneda(venta.vuelto)));
  }
  lineas.push('');
  lineas.push(centrar('Gracias por su compra!'));
  lineas.push('');
  lineas.push('');

  return lineas.join('\n');
}

// Arma el buffer de bytes ESC/POS completo: inicializacion + seleccion de
// codepage (CP850, para que tildes y enie se impriman bien) + el texto +
// avance de papel al final para poder arrancar el ticket.
function bufferTicket(venta) {
  const ESC = 0x1b;
  const partes = [];
  partes.push(Buffer.from([ESC, 0x40])); // ESC @ : reset/inicializar

  const logo = obtenerLogoBuffer();
  if (logo) {
    partes.push(Buffer.from([ESC, 0x61, 0x01])); // ESC a 1 : centrar
    partes.push(logo); // GS v 0 ... : imagen raster del logo
    partes.push(Buffer.from([0x0a])); // avance de una linea despues del logo
    partes.push(Buffer.from([ESC, 0x61, 0x00])); // ESC a 0 : volver a alinear a la izquierda
  }

  partes.push(Buffer.from([ESC, 0x74, 0x02])); // ESC t 2 : codepage CP850
  partes.push(iconv.encode(textoTicket(venta) + '\n', 'cp850'));
  partes.push(Buffer.from([0x0a, 0x0a, 0x0a, 0x0a])); // avance de papel final
  return Buffer.concat(partes);
}

module.exports = { bufferTicket, textoTicket };
