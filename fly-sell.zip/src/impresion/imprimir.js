// Impresion directa (RAW/ESC-POS) a una impresora instalada en Windows,
// sin pasar por window.print() ni por el dialogo de impresion de Windows.
// Usa el spooler de Windows (winspool.drv) via un script de PowerShell con
// una clase C# embebida (Add-Type) que llama a OpenPrinter/StartDocPrinter/
// WritePrinter con tipo de dato "RAW": los bytes le llegan a la impresora
// tal cual, sin que Chromium/GDI los re-renderice en una pagina.
const { app } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');
const { bufferTicket } = require('./escpos');

const configPath = path.join(app.getPath('userData'), 'impresora.json');

function obtenerImpresoraGuardada() {
  try {
    const raw = fs.readFileSync(configPath, 'utf-8');
    return JSON.parse(raw).nombre || null;
  } catch (e) {
    return null;
  }
}

function guardarImpresora(nombre) {
  fs.writeFileSync(configPath, JSON.stringify({ nombre }), 'utf-8');
  return true;
}

function ejecutarPowerShell(args) {
  return new Promise((resolve, reject) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', ...args],
      { windowsHide: true, maxBuffer: 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) {
          reject(new Error((stderr || stdout || err.message || '').toString().trim() || 'Error ejecutando PowerShell'));
        } else {
          resolve(stdout.toString());
        }
      }
    );
  });
}

// Lista los nombres de las impresoras instaladas en Windows.
async function listarImpresoras() {
  if (process.platform !== 'win32') return [];
  const salida = await ejecutarPowerShell(['-Command', 'Get-Printer | Select-Object -ExpandProperty Name']);
  return salida
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
}

const SCRIPT_RAW = `param([string]$PrinterName, [string]$FilePath)
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class FlySellRawPrint {
    [StructLayout(LayoutKind.Sequential)]
    public struct DOCINFOA {
        [MarshalAs(UnmanagedType.LPStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPStr)] public string pDataType;
    }
    [DllImport("winspool.drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true)]
    public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);
    [DllImport("winspool.drv", EntryPoint = "ClosePrinter", SetLastError = true)]
    public static extern bool ClosePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Ansi)]
    public static extern bool StartDocPrinter(IntPtr hPrinter, int level, [In] ref DOCINFOA di);
    [DllImport("winspool.drv", EntryPoint = "EndDocPrinter", SetLastError = true)]
    public static extern bool EndDocPrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", EntryPoint = "StartPagePrinter", SetLastError = true)]
    public static extern bool StartPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", EntryPoint = "EndPagePrinter", SetLastError = true)]
    public static extern bool EndPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", EntryPoint = "WritePrinter", SetLastError = true)]
    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);
    public static bool SendBytesToPrinter(string printerName, byte[] bytes) {
        IntPtr hPrinter;
        DOCINFOA di = new DOCINFOA();
        di.pDocName = "Fly Sell Ticket";
        di.pDataType = "RAW";
        if (!OpenPrinter(printerName, out hPrinter, IntPtr.Zero)) return false;
        try {
            if (!StartDocPrinter(hPrinter, 1, ref di)) return false;
            try {
                if (!StartPagePrinter(hPrinter)) return false;
                IntPtr pUnmanaged = Marshal.AllocHGlobal(bytes.Length);
                Marshal.Copy(bytes, 0, pUnmanaged, bytes.Length);
                int written;
                bool res = WritePrinter(hPrinter, pUnmanaged, bytes.Length, out written);
                Marshal.FreeHGlobal(pUnmanaged);
                EndPagePrinter(hPrinter);
                return res;
            } finally { EndDocPrinter(hPrinter); }
        } finally { ClosePrinter(hPrinter); }
    }
}
"@
$bytes = [System.IO.File]::ReadAllBytes($FilePath)
$ok = [FlySellRawPrint]::SendBytesToPrinter($PrinterName, $bytes)
if ($ok) { Write-Output "OK" } else { Write-Error "FALLO_IMPRESION"; exit 1 }
`;

let scriptPath = null;
function obtenerScriptPath() {
  if (!scriptPath) {
    scriptPath = path.join(app.getPath('userData'), 'imprimir-raw.ps1');
    fs.writeFileSync(scriptPath, SCRIPT_RAW, 'utf-8');
  }
  return scriptPath;
}

async function enviarRaw(buffer, nombreImpresora) {
  const archivoTmp = path.join(os.tmpdir(), `fly-sell-ticket-${Date.now()}.bin`);
  fs.writeFileSync(archivoTmp, buffer);
  try {
    await ejecutarPowerShell(['-File', obtenerScriptPath(), '-PrinterName', nombreImpresora, '-FilePath', archivoTmp]);
  } finally {
    fs.unlink(archivoTmp, () => {});
  }
}

async function imprimirTicket(venta) {
  if (process.platform !== 'win32') {
    throw Object.assign(new Error('La impresión directa solo está disponible en Windows'), { code: 'NO_WINDOWS' });
  }

  let nombreImpresora = obtenerImpresoraGuardada();

  if (!nombreImpresora) {
    const impresoras = await listarImpresoras();
    if (impresoras.length === 0) {
      throw Object.assign(new Error('No se encontró ninguna impresora instalada en Windows'), { code: 'SIN_IMPRESORAS' });
    }
    const candidata = impresoras.find((n) => /pos|58|termic|thermal/i.test(n));
    if (impresoras.length === 1) {
      nombreImpresora = impresoras[0];
      guardarImpresora(nombreImpresora);
    } else if (candidata) {
      nombreImpresora = candidata;
      guardarImpresora(nombreImpresora);
    } else {
      throw Object.assign(new Error('Hay varias impresoras instaladas, elegí cuál usar'), {
        code: 'SIN_IMPRESORA_CONFIGURADA',
        impresoras,
      });
    }
  }

  const buffer = bufferTicket(venta);
  await enviarRaw(buffer, nombreImpresora);
  return { impresora: nombreImpresora };
}

module.exports = {
  listarImpresoras,
  obtenerImpresoraGuardada,
  guardarImpresora,
  imprimirTicket,
};
